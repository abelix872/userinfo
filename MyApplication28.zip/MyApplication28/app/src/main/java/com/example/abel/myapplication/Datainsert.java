package com.example.abel.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;

public class Datainsert extends AppCompatActivity{
    public string getFullname() {
        return fullname;
    }

    public void setFullname(string fullname) {
        this.fullname = fullname;
    }

    public string getUsername() {
        return username;
    }

    public void setUsername(string username) {
        this.username = username;
    }

    public string getPassword() {
        return password;
    }

    public void setPassword(string password) {
        this.password = password;
    }

    public string getGender() {
        return gender;
    }

    public void setGender(string gender) {
        this.gender = gender;
    }

    public string getEmail() {
        return email;
    }

    public void setEmail(string email) {
        this.email = email;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    private String fullname,username,password,gender,email;
  private int mobile;


}
